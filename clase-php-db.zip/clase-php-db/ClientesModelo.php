<?php
require_once "./config/Database.php";
class ClientesModelo
{
    private int $id;
    private string $rut;
    private string $dv;
    private string $nombres;
    private string $apellidos;
    private string $fec_nac;

    public function __construct($pid, $prut, $pdv, $pnombres, $papellidos, $pfec_nac) {
        $this->id = $pid;
        $this->rut = $prut;
        $this->dv = $pdv;
        $this->nombres = $pnombres;
        $this->apellidos = $papellidos;
        $this->fec_nac = $pfec_nac;
    }
    
    public function mostrarClientes() {
        $conexion = new Database();
        $clientes = $conexion->query("SELECT * FROM clientes");
        $conexion->close();
        $conexion = null;
        return $clientes;
    }

    public function crearClientes($nombres, $apellido_p, $apellido_m) {
        $conexion = new Database();
        $cliente = $conexion->execute("INSERT INTO clientes (nombres,apellido_p,apellido_m) VALUES ($nombres, $apellido_p, $apellido_m)");
        $conexion->close();
        $conexion = null;
        return $cliente;
    }
}
?>