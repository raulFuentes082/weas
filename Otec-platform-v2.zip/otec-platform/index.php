<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTEC Platform</title>
    <link rel="stylesheet" href="assets/css.css">
</head>
<body>

<nav class="navbar">
    <div class="navbar-inner">
        <span class="navbar-brand">OTEC<span> Platform</span></span>
        <ul class="navbar-links">
            <li><a href="auth/login.php">Iniciar sesión</a></li>
            <li><a href="auth/register.php" class="btn btn-sm">Registrarse</a></li>
        </ul>
    </div>
</nav>

<div class="banner">
    <h1>Bienvenido a <span>OTEC</span> Platform</h1>
    <p>Plataforma de formación y capacitación estudiantil. Aprende, certifícate y crece.</p>
    <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
        <a href="auth/register.php" class="btn">Crear cuenta</a>
        <a href="auth/login.php" class="btn-outline">Iniciar sesión</a>
    </div>
</div>

<section class="section-who" id="who">
    <div class="container">
        <h2>¿Quiénes somos?</h2>
        <p>Somos una OTEC estudiantil comprometida con la educación de calidad. Ofrecemos cursos prácticos y certificaciones reconocidas para impulsar tu desarrollo profesional.</p>
    </div>
</section>

<section style="padding: 70px 24px; background: var(--black);">
    <div class="container">
        <h2 style="color:var(--white); margin-bottom:8px;">Nuestros cursos</h2>
        <p style="margin-bottom:28px;">Explora nuestra oferta de capacitaciones disponibles.</p>
        <div class="cards-grid">
            <div class="card">
                <h3>📊 Excel Avanzado</h3>
                <p>Domina fórmulas, tablas dinámicas y automatización con macros.</p>
            </div>
            <div class="card">
                <h3>💻 Ofimática</h3>
                <p>Aprende las herramientas de oficina más usadas en el mundo laboral.</p>
            </div>
            <div class="card">
                <h3>🎯 Habilidades Blandas</h3>
                <p>Comunicación efectiva, trabajo en equipo y liderazgo.</p>
            </div>
        </div>
        <div style="text-align:center; margin-top:32px;">
            <a href="auth/register.php" class="btn">Inscribirme ahora</a>
        </div>
    </div>
</section>

<footer style="background:var(--black-2); border-top:1px solid var(--black-5); padding:24px; text-align:center;">
    <p style="color:var(--grey-dark); font-size:0.85rem;">© <?php echo date('Y'); ?> OTEC Platform — Todos los derechos reservados</p>
</footer>

<script src="assets/js.js"></script>
</body>
</html>
